# Expanded Choc V2 keyboard

Start with the [Choc V2 build guide](choc-v2/README.md). This wireless split has 29 south-facing hot-swap switches per hand and an indexed folding thumb deck.

1. **Test the switch fit.** Print the [one-switch coupon](choc-v2/case/choc-fit-coupon.stl) at 100% and try your PG1353 switch and keycap.
2. **Print the keyboard.** Use the eight [Choc V2 production STLs](choc-v2/case/print/).
3. **Order the boards.** Submit each of the four [fabrication ZIPs](choc-v2/pcb/fabrication/) as a separate 1.6 mm two-layer board. Use the [parts list](choc-v2/BOM.csv) for assembly.
4. **Flash the two controllers.** Use the [handed UF2s and pairing instructions](choc-v2/firmware/README.md).
5. **Inspect or edit the geometry.** Open the [Choc V2 Blender model](choc-v2/case/Expanded-Choc-V2.blend) or one of the four KiCad projects linked in the build guide.

All production files for this edition are under `choc-v2/`. The files at the outer level supply the shared mechanical template and code used by the Blender regeneration scripts. Physical clip retention, typing under load, cable flex life and wireless operation still need testing on a built pair.
