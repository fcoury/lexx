# Expanded MX keyboard prototype

Start with the [PCB build guide](pcb/README.md). Each hand has 26 finger keys, three folding thumb keys, and a XIAO nRF52840.

1. Print the [A4 fit sheets](pcb/expanded-mx-fit-sheets.pdf) at 100% and check the 50 mm bar against a ruler.
2. Print the four [PCB shells](pcb/case/print/) and the four switch plates labeled fixed_plate and thumb_plate under [print/expanded](print/expanded/). The PCB case uses the indexed M3 hinge.
3. For a PCB order, upload each of the four individual **-fabrication.zip** files from [pcb/fabrication](pcb/fabrication/) as a separate two-layer 1.6 mm FR-4 board. One board of each design makes one keyboard.
4. Use the [BOM](pcb/BOM.csv), the [assembly instructions](pcb/README.md) and the [matching left and right firmware](pcb/firmware/README.md).

The editable KiCad projects are listed in the [board table](pcb/README.md). Move them with the full pcb directory to keep the shared libraries. The [Blender assembly](pcb/case/Expanded-PCB.blend) includes the moving electronics and thumb-angle slider. [Hinge sourcing notes](hinge-sourcing.md) cover alternative hardware.

CAD and electrical checks passed. Real cable motion, key and socket fit, battery assembly and radio operation still need a physical prototype.
