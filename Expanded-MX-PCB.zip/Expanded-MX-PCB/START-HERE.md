# Expanded MX keyboard · Revision B

All 58 hot-swap MX switches face south. The near edge of each angled thumb key carries its LED window. Each hand uses a 26-key finger PCB, a three-key folding thumb PCB and a wireless XIAO nRF52840 controller.

1. **Check the fit.** Print the [left and right A4 fit sheets](pcb/expanded-mx-fit-sheets.pdf) at 100%. Check the 50 mm scale bar with a ruler. The [top view](pcb/south-facing-layout.png) shows all switch orientations.
2. **Print the case.** Use the eight [revision B STL files](pcb/case/print/). Each hand needs its matching fixed shell, fixed plate, thumb shell and thumb plate. The fixed plate and shell have a new mounting-post location and a rear flex-connector extension. These parts use the indexed M3 hinge. The [case guide](pcb/case/README.md) covers printing and assembly.
3. **Order the boards.** Upload each of the four individual Gerber and drill archives in [pcb/fabrication](pcb/fabrication/) as a separate two-layer, 1.6 mm FR-4 PCB. Order one of each design for a complete keyboard.
4. **Assemble and test.** Follow the [purchasing BOM](pcb/BOM.csv), [PCB build guide](pcb/README.md) and [firmware instructions](pcb/firmware/README.md).

The editable KiCad projects are linked in the [board table](pcb/README.md). Keep their shared libraries under pcb. The [Blender assembly](pcb/case/Expanded-PCB.blend) includes the moving electronics and the thumb-angle slider.

The electrical and rigid-body clearance checks are digital. Bench-test socket insertion, USB and battery operation, the flexible cable at intermediate angles, and radio pairing on the first assembled pair.
