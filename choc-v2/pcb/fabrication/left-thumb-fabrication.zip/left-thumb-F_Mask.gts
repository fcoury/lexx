%TF.GenerationSoftware,KiCad,Pcbnew,10.0.8*%
%TF.CreationDate,2026-11-21T18:50:04-03:00*%
%TF.ProjectId,left-thumb,6c656674-2d74-4687-956d-622e6b696361,A*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.8) date 2026-11-21 18:50:04*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMHorizOval*
0 Thick line with rounded ends*
0 $1 width*
0 $2 $3 position (X,Y) of the first rounded end (center of the circle)*
0 $4 $5 position (X,Y) of the second rounded end (center of the circle)*
0 Add line between two ends*
20,1,$1,$2,$3,$4,$5,0*
0 Add two circle primitives to create the rounded ends*
1,1,$1,$2,$3*
1,1,$1,$4,$5*%
G04 Aperture macros list end*
%ADD10O,1.650000X2.050000*%
%ADD11C,3.000000*%
%ADD12C,5.000000*%
%ADD13HorizOval,1.650000X-0.048384X-0.194059X0.048384X0.194059X0*%
%ADD14C,0.900000*%
%ADD15HorizOval,1.650000X-0.093894X-0.176590X0.093894X0.176590X0*%
G04 APERTURE END LIST*
D10*
%TO.C,SW27*%
X114396030Y-159476280D03*
D11*
X119396030Y-148376280D03*
D12*
X119396030Y-154326280D03*
D11*
X124396030Y-150576280D03*
%TD*%
D13*
%TO.C,SW28*%
X136337255Y-160923574D03*
D11*
X143874065Y-151362900D03*
D12*
X142434630Y-157136160D03*
D11*
X148193316Y-154707161D03*
%TD*%
D14*
%TO.C,S1*%
X178730000Y-112500000D03*
X178730000Y-115500000D03*
%TD*%
D15*
%TO.C,SW29*%
X157283393Y-167658452D03*
D11*
X166909266Y-160205092D03*
D12*
X164115910Y-165458630D03*
D11*
X170291166Y-164494934D03*
%TD*%
M02*
